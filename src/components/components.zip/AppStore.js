    import React, { useState } from 'react';
    import Header from './Header';
    import Featured from './Featured';
    import Categories from './Categories';
    import AppCard from './AppCard';
    import './AppStore.css';

    const AppStore = () => {
        const [searchTerm, setSearchTerm] = useState('');
        const [selectedCategory, setSelectedCategory] = useState(null);

        const handleSearchChange = (event) => {
            setSearchTerm(event.target.value);
        };
        const categories = [
            {
            
        name: 'Games',
        apps: [
            { 
                name: 'Vietnam BlackOps', 
                description: "We're in Vietnam!", 
                icon: require('../Images/blackops.jpg'), 
                link: 'https://download948.mediafire.com/gghd9waxbvlgX_LluidTwX3R8e5RKzYsXXecgK6ePfj02uhOw5If4F8cRbnVtYB6v88NWoIyXky2QVfd08MJs2wQmK5gErSNWwnCwFeCuwlNh4QA4_bomx1u5TPW2BxIGqccaD1hXPcK-orKpetPxYAEYA3fn9ujRhVbub4Luhdu4w/ciuynl3m3k2k8ek/Vietnam_Black_Ops_Win_ROM_EN.zip'
            },
            { 
                name: 'Chess', 
                description: 'Play Chess FREE at #1 Chess Site!', 
                icon: require('../Images/chess.png'), 
                link: 'https://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJyaXNlSW5zdGFsbGVyIiwiZG93bmxvYWRVcmwiOiJodHRwczovL2QyYXRkem45a2RzazU3LmNsb3VkZnJvbnQubmV0L2N1cnJlbnQvaW4vdjQuNjE0LjE3OC43MS4zIiwiYXBwSWQiOiI0MGYyMGY1MC05OWViLTExZTYtYTdmYi0wMDE2M2VkODMzZTciLCJwbGF0Zm9ybUlkIjoid2luZG93cyIsImlhdCI6MTcyNTQwNTEzOSwiZXhwIjoxNzI1NDA4NzM5fQ.Wmdbl1QK4MQ9ZieKQOHt9wnOwOjyzeRaMW1WDoRp83o'
            },
            { 
                name: 'Need for Speed 2 SE', 
                description: 'The thrill of the Chase!', 
                icon: require('../Images/needforspeed.jpg'),
                link: 'https://www.myabandonware.com/download/lvp7-need-for-speed-ii-se'
            },
            { 
                name: 'World Championship Snooker', 
                description: 'Every Shot Counts', 
                icon: require('../Images/snooker.jpg'), 
                link: 'https://download856.mediafire.com/uev5ca53knbg3RH42ll6iyOdZvSMwLVJs5jAQWnCvqWG8JN8XMhl2gCGfzLJOscTlANS2imarV275LO_46ryppifHGftBssPQ3deSGXU3Zx1-AFJeoTfGjzxlQsjMOddHrsxhhtSmQRiGfsYM2nFrGxyMbzJcUabgL4xV_kMQ0clGQ/kbin8j8mmd1bjhw/World_Championship_Snooker_2004_Win_ISO_EN.zip'
            },
            { 
                name: 'OpenTTD', 
                description: 'Become the Transport Tycoon', 
                icon: require('../Images/OpenTTD.jpg'), 
                link: 'https://cdn.openttd.org/openttd-releases/14.1/openttd-14.1-windows-win64.exe'
            }
        ]
            },
            {
                name: 'Productivity',
                apps: [
                    { name: 'LibreOffice', description: 'Office for free', icon: require('../Images/LibreOffice.png'),
                        link: 'https://download.documentfoundation.org/libreoffice/stable/24.8.0/win/x86_64/LibreOffice_24.8.0_Win_x86-64.msi',
                    },
                    { name: 'Todoist', description: 'A Todolist to organize your life', icon: require('../Images/Todoist.png'),
                        link: 'https://todoist.com/windows_app'
                    },
                    { name: 'Obsidian', description: 'Sharpen your thinking', icon: require('../Images/Obsidian.jpg'),
                        link: 'https://www.alomware.com/files/Toolbox_v5004.zip'
                    },
                    { name:'Alomware Toolbox', description: 'Enhance your productivity.', icon: require('../Images/alomwaretoolbox.avif'),
                        link: 'https://www.alomware.com/files/Toolbox_v5004.zip'},
                    { name: 'Sunsama', description: 'Make Work-Life Balance a reality', icon: require('../Images/sunsama.jpg'),
                        link: 'https://desktop.sunsama.com/'
                    }
                ]
            },
            {
                name: 'Social',
                apps: [
                    { name: 'WhatsApp', description: 'Message Privately.', icon: require('../Images/whatsapp.png'),
                        link: 'https://get.microsoft.com/installer/download/9NKSQGP7F2NH?cid=website_cta_psi'
                    },
                    { name: 'Instagram', description: 'Share moments..', icon: require('../Images/insta.jpg'),
                        link: 'https://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJyaXNlSW5zdGFsbGVyIiwiZG93bmxvYWRVcmwiOiJodHRwczovL2QybDc5ZjdxYzN2aTV2LmNsb3VkZnJvbnQubmV0L3JlbGVhc2UvaW4vdjMuMjA2Ljc2LjA4LjczIiwiYXBwSWQiOiJmOTZkZjg3ZC05MjZmLTQ5NTQtYmY1OC1mMzc3YTU3M2E2MzAiLCJwbGF0Zm9ybUlkIjoid2luZG93cyIsImlhdCI6MTcyNTQwNjM1MywiZXhwIjoxNzI1NDA5OTUzfQ.yHuayd7DisWbNfn1eNwBH23dkhrDLstanhA9yN40_uw'
                    },
                    { name: 'Reddit', description: 'Dive into anything.', icon: require('../Images/reddit.png'),
                        link: 'https://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJyZWRpcmVjdGlvbkRvd25sb2FkIiwiZG93bmxvYWRVcmwiOiJodHRwczovL3d3dy5taWNyb3NvZnQuY29tL2VuLXVzL3AvcmVkZGl0LzluczNyYnE1aHY1ZiIsImFwcElkIjoiODE0MTc3YWYtNmEyYi00MjJkLTk0ZTItNjIyYTkyZWE1NWEwIiwicGxhdGZvcm1JZCI6IndpbmRvd3MiLCJpYXQiOjE3MjU0MDY1ODYsImV4cCI6MTcyNTQxMDE4Nn0.X5bmVyGotEuV9T15RMToWx4htIKG9Es4ilyWYw1vxSw'
                    },
                    { name: 'Telegram', description: 'A New Era of Messaging', icon: require('../Images/telegram.png'),
                        link: 'https://telegram.org/dl/desktop/win64 '
                    },
                    { name: 'LinkedIn', description: 'Welcome Professionals', icon: require('../Images/Linkedin.png'),
                        link: 'https://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJyZWRpcmVjdGlvbkRvd25sb2FkIiwiZG93bmxvYWRVcmwiOiJodHRwczovL2FwcHMubWljcm9zb2Z0LmNvbS9kZXRhaWwvbGlua2VkaW4vOVdaRE5DUkZKNFE3P2hsPWVuLXVzJmdsPVVTIiwiYXBwSWQiOiIyNjZlZjM3My0yNTYxLTQxZTQtOTQwNy1iMWFjMWZhZGM5MTYiLCJwbGF0Zm9ybUlkIjoid2luZG93cyIsImlhdCI6MTcyNTQwNjY5NywiZXhwIjoxNzI1NDEwMjk3fQ.hjgFOiGbhAA7J_ezxTo8AyoozA7WEsWxq6Gw427jgeA'
                    }
                ]
            },
            {
                name: 'Music',
                apps: [
                    { name: 'iTunes', description: 'Think Different.', icon:  require('../Images/itunes.png'),
                        link: 'https://www.techspot.com/downloads/downloadnowfile/70/?evp=674240c7e60c1cc6f5cace58684d6694&file=94'
                    },
                    { name: 'WinAmp', description: 'Lightweight music player', icon:  require('../Images/winamp.jpg'),
                        link: 'https://winamp-lite.en.softonic.com/download'

                    },
                    { name: 'foobar2000', description: 'Freeware audio player', icon:  require('../Images/foobar.png'),
                        link: 'https://www.foobar2000.org/files/foobar2000-x64_v2.1.5.exe://www.techspot.com/downloads/downloadnowfile/70/?evp=674240c7e60c1cc6f5cace58684d6694&file=94'
                    },
                    { name: 'Aimp', description: 'Listen offline.', icon:  require('../Images/aimp.jpg'),
                        link: 'https://www.aimp.ru/?do=download.file&id=34'
                    },
                    { name: 'Tidal', description: 'Extraordinary sound quality', icon: require('../Images/tidal.png'),
                        link: 'https://www.techspot.com/downloads/downloadnowfile/70/?evp=674240c7e60c1cc6f5cace58684d6694&file=94https://download.tidal.com/desktop/TIDALSetup.exe'
                    }
                ]
            },
            {
                name: 'Education',
                apps: [
                    { name: 'Scratch', description: 'Learn to Code', icon: require('../Images/scratch.png'),
                        link: 'https://dl.download.it/US/mit-scratch.exe?st=IsUFxEo_FQbI-gp7NapjpA&e=1725417949'
                    },
                    { name: 'Desmos', description: 'Beautiful free math', icon: require('../Images/desmos.jpg'),
                        link: 'https://dl.download.it/US/desmos-graphing-calculator.apk?st=btVnuMRD3Esj9ro3svh0mQ&e=1725417891'
                    },
                    { name: 'Udemy', description: 'The power of possibilities.', icon: require('../Images/Udemy.png'),
                        link: 'https://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJhZmZpbGlhdGlvbkRvd25sb2FkIiwiZG93bmxvYWRVcmwiOiJodHRwczovL2NsaWNrLmxpbmtzeW5lcmd5LmNvbS9mcy1iaW4vY2xpY2s_aWQ9d2JOY01ZWFRUd1Umb2ZmZXJpZD0xNTk3MzA5LjIwOTA3JnR5cGU9MyZzdWJpZD0wIiwiYXBwSWQiOiI0ZWJkNTI5ZC1hYTJmLTRkZjgtOTc1OC04MzIyMjdkODdjNGYiLCJwbGF0Zm9ybUlkIjoid2luZG93cyIsImlhdCI6MTcyNTQwNzAzOSwiZXhwIjoxNzI1NDEwNjM5fQ.rIdSlEb47AHROd6wjPY317O_zYb_OaBSDPBHmXnvwCE'
                    },
                    { name: 'PythonTutor', description: 'Learn Python', icon: require('../Images/python-tutor-python tutor.avif'),
                        link: 'https://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJyZWRpcmVjdGlvbkRvd25sb2FkIiwiZG93bmxvYWRVcmwiOiJodHRwczovL3d3dy5taWNyb3NvZnQuY29tL2VuLXVzL3N0b3JlL3AvcHl0aG9uLXR1dG9yLzl3emRuY3JkbTRtaiIsImFwcElkIjoiMWZkYzBmZGItNDUxNS00MjY4LWIzOGUtOGMxMzgyNjljMDI5IiwicGxhdGZvcm1JZCI6IndpbmRvd3MiLCJpYXQiOjE3MjU0MDY4ODIsImV4cCI6MTcyNTQxMDQ4Mn0.R8oIKkmplNGjHX-IMngvCSme9dvsME-MtaKb5Lnmjjshttps://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJyZWRpcmVjdGlvbkRvd25sb2FkIiwiZG93bmxvYWRVcmwiOiJodHRwczovL3d3dy5taWNyb3NvZnQuY29tL2VuLXVzL3N0b3JlL3AvcHl0aG9uLXR1dG9yLzl3emRuY3JkbTRtaiIsImFwcElkIjoiMWZkYzBmZGItNDUxNS00MjY4LWIzOGUtOGMxMzgyNjljMDI5IiwicGxhdGZvcm1JZCI6IndpbmRvd3MiLCJpYXQiOjE3MjU0MDY4ODIsImV4cCI6MTcyNTQxMDQ4Mn0.R8oIKkmplNGjHX-IMngvCSme9dvsME-MtaKb5Lnmjjs'
                    },
                    { name: 'CodeAcademy', description: 'Learn to Code', icon: require('../Images/codeacademy.jpg'),
                        link: 'https://en.softonic.com/download-launch?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkb3dubG9hZFR5cGUiOiJyZWRpcmVjdGlvbkRvd25sb2FkIiwiZG93bmxvYWRVcmwiOiJodHRwczovL3d3dy5jb2RlY2FkZW15LmNvbS9yZWdpc3Rlcj9yZWRpcmVjdD0lMkYiLCJhcHBJZCI6IjA2ZDIxNzU4LTc2YTAtNDM0Yy05ZDY2LWYxZTI4YTQ0YjBlMCIsInBsYXRmb3JtSWQiOiJ3aW5kb3dzIiwiaWF0IjoxNzI1NDA2ODMyLCJleHAiOjE3MjU0MTA0MzJ9.0XNK2RvzeEd6d5gtRMYiGWQeuL3qFNMC9tZ8qsLIPI8'
                    }
                ]
            }
        ];
        const filteredCategories = categories.map(category => ({
            ...category,
            apps: category.apps.filter(app =>
                app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                app.description.toLowerCase().includes(searchTerm.toLowerCase())
            )
        }));

        const handleCategoryClick = (categoryName) => {
            setSelectedCategory(categoryName);
        };

        const filteredApps = selectedCategory
            ? filteredCategories.find(category => category.name === selectedCategory).apps
            : [];

        return (
            <div className="app-store">
                <Header 
                    searchTerm={searchTerm} 
                    onSearchChange={handleSearchChange} 
                />
                <Featured />
                <Categories 
                    categories={categories} 
                    onCategoryClick={handleCategoryClick} 
                />
                <div className="category-section">
                    <h2>{selectedCategory || 'Select a category'}</h2>
                    <div className="app-grid">
                    {filteredApps.map((app) => (
                 <AppCard
                     key={app.name}
                    appName={app.name}
                    appDescription={app.description}
                    appIcon={app.icon}
                    appLink={app.link}  // Pass the download link here
                />
                    ))}
                    </div>
                </div>
            </div>
        );
    }


    export default AppStore;